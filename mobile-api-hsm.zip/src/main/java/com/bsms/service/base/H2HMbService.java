package com.bsms.service.base;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.HttpHeaders;

import com.bsms.restobj.MbApiReq;
import com.bsms.restobj.MbApiResp;

public interface H2HMbService {
	public MbApiResp process(HttpHeaders header, ContainerRequestContext requestContext, MbApiReq request) throws Exception;
}
