package com.bsms.restobj;

public interface MbApiContentReq {

}
