package com.bsms.restobj;

public interface MbApiContentResp {

}
