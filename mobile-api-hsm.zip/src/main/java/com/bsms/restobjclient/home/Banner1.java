package com.bsms.restobjclient.home;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Banner1 {
	private String img;
	
	public Banner1(String img) {
				
				this.img=img;
			
	}
}
